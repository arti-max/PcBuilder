import pygame
import time
import threading
from api.Device import Device

class Buzzer(Device):
    def __init__(self, canvas):
        super().__init__(canvas, "Buzzer")
        
        # Серийный номер устройства
        self.serial_number = self.config.get("serial_number", 0x2F)
        
        # Размеры устройства (компактный)
        self.device_width = self.config.get("device_width", 120)
        self.device_height = self.config.get("device_height", 80)
        self.frame_thickness = 4
        
        self.width = self.device_width
        self.height = self.device_height
        self.surface = pygame.Surface((self.width, self.height))
        
        # Цветовая схема
        self.background_color = self.config.get("background_color", [40, 40, 40])
        self.frame_color = self.config.get("frame_color", [60, 60, 60])
        self.border_color = self.config.get("border_color", [100, 100, 100])
        self.speaker_color = self.config.get("speaker_color", [80, 80, 80])
        self.active_color = self.config.get("active_color", [255, 100, 100])  # Красный при звуке
        self.text_color = self.config.get("text_color", [200, 200, 200])
        
        # Состояние звука
        self.is_playing = False
        self.current_pattern = None
        self.play_thread = None
        self.stop_flag = False
        
        # Анимация
        self.blink_state = False
        self.last_blink_time = time.time()
        self.animation_intensity = 0  # 0-1 для плавной анимации
        
        # Звуковые паттерны
        self.sound_patterns = {
            0x01: {"name": "BEEP", "pattern": [0.1], "repeat": 1},           # Короткий сигнал
            0x02: {"name": "ERROR", "pattern": [0.5], "repeat": 1},          # Длинный сигнал  
            0x03: {"name": "DISPLAY", "pattern": [0.1, 0.1, 0.1], "repeat": 3}, # Тройной для дисплея
            0x04: {"name": "KEYBOARD", "pattern": [0.1, 0.2, 0.1], "repeat": 2}, # Двойной для клавиатуры
            0x05: {"name": "TAPE", "pattern": [0.05, 0.05, 0.05, 0.05], "repeat": 2}, # Частые для кассетника
            0x07: {"name": "CRITICAL", "pattern": [0.2, 0.1, 0.2, 0.1, 0.2], "repeat": 5}, # Критическая ошибка
        }
        
        # Инициализация звука
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
            self.sound_enabled = True
        except:
            self.sound_enabled = False
            print("Buzzer: звук недоступен, только визуальная индикация")
        
        # Шрифты
        pygame.font.init()
        self.font = pygame.font.Font(None, 16)
        self.small_font = pygame.font.Font(None, 12)
        
    def get_default_config(self):
        config = super().get_default_config()
        config.update({
            "serial_number": 0x2F,
            "device_width": 120,
            "device_height": 80,
            "background_color": [40, 40, 40],
            "frame_color": [60, 60, 60],
            "border_color": [100, 100, 100],
            "speaker_color": [80, 80, 80],
            "active_color": [255, 100, 100],
            "text_color": [200, 200, 200],
            "width": 120,
            "height": 80,
            "x": 800,
            "y": 50
        })
        return config
    
    def generate_beep_sound(self, frequency=800, duration=0.1):
        """Генерирует звуковой сигнал"""
        if not self.sound_enabled:
            return None
        
        sample_rate = 22050
        frames = int(duration * sample_rate)
        
        import numpy as np
        # Генерируем синусоидальную волну
        wave_array = np.sin(2 * np.pi * frequency * np.linspace(0, duration, frames))
        
        # Применяем огибающую для избежания щелчков
        fade_frames = int(0.01 * sample_rate)  # 10ms fade
        wave_array[:fade_frames] *= np.linspace(0, 1, fade_frames)
        wave_array[-fade_frames:] *= np.linspace(1, 0, fade_frames)
        
        # Конвертируем в 16-битный формат
        wave_array = (wave_array * 32767).astype(np.int16)
        
        # Создаем стерео звук
        stereo_wave = np.zeros((frames, 2), dtype=np.int16)
        stereo_wave[:, 0] = wave_array
        stereo_wave[:, 1] = wave_array
        
        return pygame.sndarray.make_sound(stereo_wave)
    
    def play_pattern(self, pattern_id):
        """Воспроизводит звуковой паттерн"""
        if pattern_id not in self.sound_patterns:
            print(f"Buzzer: неизвестный паттерн 0x{pattern_id:02X}")
            return
        
        # Останавливаем предыдущий звук
        self.stop_sound()
        
        pattern = self.sound_patterns[pattern_id]
        self.current_pattern = pattern
        self.is_playing = True
        self.stop_flag = False
        
        print(f"Buzzer: воспроизведение паттерна '{pattern['name']}'")
        
        # Запускаем воспроизведение в отдельном потоке
        self.play_thread = threading.Thread(target=self._play_pattern_thread, args=(pattern,))
        self.play_thread.daemon = True
        self.play_thread.start()
    
    def _play_pattern_thread(self, pattern):
        """Поток воспроизведения паттерна"""
        try:
            for repeat in range(pattern["repeat"]):
                if self.stop_flag:
                    break
                
                for i, duration in enumerate(pattern["pattern"]):
                    if self.stop_flag:
                        break
                    
                    # Частота зависит от позиции в паттерне
                    frequency = 800 + (i * 100)  # Варьируем частоту
                    
                    # Воспроизводим звук
                    if self.sound_enabled:
                        try:
                            sound = self.generate_beep_sound(frequency, duration)
                            if sound:
                                sound.play()
                        except Exception as e:
                            print(f"Buzzer: ошибка воспроизведения: {e}")
                    
                    # Визуальная индикация
                    self.animation_intensity = 1.0
                    
                    # Ждем окончания звука
                    time.sleep(duration)
                    
                    # Пауза между звуками в паттерне
                    if i < len(pattern["pattern"]) - 1:
                        self.animation_intensity = 0.0
                        time.sleep(0.05)
                
                # Пауза между повторениями
                if repeat < pattern["repeat"] - 1:
                    self.animation_intensity = 0.0
                    time.sleep(0.3)
        
        except Exception as e:
            print(f"Buzzer: ошибка в потоке воспроизведения: {e}")
        finally:
            self.is_playing = False
            self.animation_intensity = 0.0
            self.current_pattern = None
    
    def stop_sound(self):
        """Останавливает воспроизведение"""
        self.stop_flag = True
        self.is_playing = False
        self.animation_intensity = 0.0
        
        if self.sound_enabled:
            pygame.mixer.stop()
        
        if self.play_thread and self.play_thread.is_alive():
            self.play_thread.join(timeout=0.1)
        
        print("Buzzer: воспроизведение остановлено")
    
    def update(self):
        """Обновляет состояние устройства"""
        current_time = time.time()
        
        # Обновляем анимацию мигания
        if self.is_playing:
            if current_time - self.last_blink_time >= 0.1:
                self.blink_state = not self.blink_state
                self.last_blink_time = current_time
            
            # Плавное затухание интенсивности
            if self.animation_intensity > 0:
                self.animation_intensity = max(0, self.animation_intensity - 0.05)
        else:
            self.blink_state = False
            self.animation_intensity = 0
    
    def draw(self):
        """Рисует устройство"""
        # Фон
        self.surface.fill(self.background_color)
        
        # Внешняя рамка
        outer_rect = pygame.Rect(0, 0, self.width, self.height)
        pygame.draw.rect(self.surface, self.frame_color, outer_rect)
        pygame.draw.rect(self.surface, self.border_color, outer_rect, 2)
        
        # Внутренняя область
        inner_rect = pygame.Rect(
            self.frame_thickness,
            self.frame_thickness,
            self.width - self.frame_thickness * 2,
            self.height - self.frame_thickness * 2
        )
        pygame.draw.rect(self.surface, [30, 30, 30], inner_rect)
        
        # Рисуем динамик
        self._draw_speaker()
        
        # Статус
        self._draw_status()
        
        # Лейбл устройства
        label_text = self.small_font.render("BUZZER", True, [150, 150, 150])
        label_rect = label_text.get_rect()
        label_rect.centerx = self.width // 2
        label_rect.bottom = self.height - 3
        self.surface.blit(label_text, label_rect)
    
    def _draw_speaker(self):
        """Рисует динамик"""
        center_x = self.width // 2
        center_y = self.height // 2 - 5
        
        # Основной корпус динамика
        speaker_rect = pygame.Rect(center_x - 20, center_y - 15, 40, 30)
        
        # Цвет зависит от состояния
        if self.is_playing and self.blink_state:
            speaker_color = [
                min(255, self.speaker_color[0] + int(self.animation_intensity * 175)),
                min(255, self.speaker_color[1] + int(self.animation_intensity * 20)),
                min(255, self.speaker_color[2] + int(self.animation_intensity * 20))
            ]
        else:
            speaker_color = self.speaker_color
        
        pygame.draw.rect(self.surface, speaker_color, speaker_rect)
        pygame.draw.rect(self.surface, self.border_color, speaker_rect, 2)
        
        # Решетка динамика
        for i in range(3):
            for j in range(6):
                hole_x = speaker_rect.x + 8 + j * 4
                hole_y = speaker_rect.y + 8 + i * 4
                pygame.draw.circle(self.surface, [50, 50, 50], (hole_x, hole_y), 1)
        
        # Звуковые волны при воспроизведении
        if self.is_playing and self.animation_intensity > 0:
            wave_color = [
                int(255 * self.animation_intensity),
                int(100 * self.animation_intensity),
                int(100 * self.animation_intensity)
            ]
            
            # Рисуем волны справа от динамика
            for i in range(3):
                wave_x = speaker_rect.right + 5 + i * 3
                wave_y1 = center_y - (5 + i * 2)
                wave_y2 = center_y + (5 + i * 2)
                
                pygame.draw.arc(self.surface, wave_color, 
                               (wave_x - 5, wave_y1, 10, wave_y2 - wave_y1), 
                               -0.5, 0.5, 2)
    
    def _draw_status(self):
        """Рисует статус устройства"""
        status_y = self.height - 25
        
        if self.is_playing and self.current_pattern:
            status_text = f"PLAYING: {self.current_pattern['name']}"
            color = self.active_color
        else:
            status_text = "READY"
            color = self.text_color
        
        text_surface = self.small_font.render(status_text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.centerx = self.width // 2
        text_rect.y = status_y
        self.surface.blit(text_surface, text_rect)
    
    def device_in(self, value):
        """Получает команды от процессора"""
        self._last_command = value
        
        if value == 0x2F:  # Запрос серийного номера
            print("Buzzer: запрос серийного номера")
            return
        elif value == 0x06:  # Стоп
            self.stop_sound()
            return
        elif value in self.sound_patterns:
            self.play_pattern(value)
            return
        else:
            print(f"Buzzer: неизвестная команда 0x{value:02X}")
    
    def device_out(self):
        """Отправляет данные процессору"""
        if hasattr(self, '_last_command') and self._last_command == 0x2F:
            self._last_command = None
            print(f"Buzzer: отправлен серийный номер 0x{self.serial_number:02X}")
            return self.serial_number
        
        # Возвращаем статус воспроизведения
        status = 0x01 if self.is_playing else 0x00
        return status
    
    def get_serial_number(self):
        return self.serial_number
